create extension if not exists pgcrypto;
create table if not exists public.profiles (id uuid primary key references auth.users(id) on delete cascade, name text, created_at timestamptz not null default now());
create table if not exists public.transactions (id uuid primary key default gen_random_uuid(), user_id uuid not null references auth.users(id) on delete cascade, type text not null check(type in ('expense','income')), description text not null, category text not null default 'Outros', amount numeric(14,2) not null check(amount>=0), transaction_date date not null default current_date, scheduled_account_id uuid, created_at timestamptz not null default now());
create table if not exists public.scheduled_accounts (id uuid primary key default gen_random_uuid(), user_id uuid not null references auth.users(id) on delete cascade, name text not null, category text not null default 'Contas', amount numeric(14,2) not null check(amount>=0), due_date date not null, recurrence text not null default 'single' check(recurrence in ('single','monthly','installments')), installment_total integer, installment_number integer default 1, series_id uuid, paid boolean not null default false, paid_at timestamptz, created_at timestamptz not null default now());
do $$ begin if not exists(select 1 from pg_constraint where conname='transactions_scheduled_account_id_fkey') then alter table public.transactions add constraint transactions_scheduled_account_id_fkey foreign key(scheduled_account_id) references public.scheduled_accounts(id) on delete set null; end if; end $$;
alter table public.profiles enable row level security; alter table public.transactions enable row level security; alter table public.scheduled_accounts enable row level security;
drop policy if exists "own profiles" on public.profiles; create policy "own profiles" on public.profiles for all to authenticated using(auth.uid()=id) with check(auth.uid()=id);
drop policy if exists "own transactions" on public.transactions; create policy "own transactions" on public.transactions for all to authenticated using(auth.uid()=user_id) with check(auth.uid()=user_id);
drop policy if exists "own scheduled accounts" on public.scheduled_accounts; create policy "own scheduled accounts" on public.scheduled_accounts for all to authenticated using(auth.uid()=user_id) with check(auth.uid()=user_id);
create or replace function public.handle_new_user() returns trigger language plpgsql security definer set search_path=public as $$ begin insert into public.profiles(id,name) values(new.id,coalesce(new.raw_user_meta_data->>'name',split_part(coalesce(new.email,''),'@',1))) on conflict(id) do nothing; return new; end; $$;
drop trigger if exists on_auth_user_created on auth.users; create trigger on_auth_user_created after insert on auth.users for each row execute procedure public.handle_new_user();
insert into public.profiles(id,name) select id,coalesce(raw_user_meta_data->>'name',split_part(coalesce(email,''),'@',1)) from auth.users on conflict(id) do nothing;

-- V15: meses pagos para contas recorrentes/parceladas
alter table public.scheduled_accounts
  add column if not exists paid_months text[] not null default '{}'::text[];

grant select, insert, update, delete on public.scheduled_accounts to authenticated;
grant select, insert, update, delete on public.transactions to authenticated;
