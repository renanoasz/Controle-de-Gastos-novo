-- MEU CONTROLE V15 — atualização sem apagar dados
-- Execute no Supabase > SQL Editor > New query > Run

alter table public.scheduled_accounts
  add column if not exists paid_months text[] not null default '{}'::text[];

grant select, insert, update, delete on public.scheduled_accounts to authenticated;
grant select, insert, update, delete on public.transactions to authenticated;

alter table public.scheduled_accounts enable row level security;
alter table public.transactions enable row level security;

-- Confirma a estrutura esperada pela V15
alter table public.scheduled_accounts add column if not exists category text default 'Contas';
alter table public.scheduled_accounts add column if not exists installment_total integer;
alter table public.scheduled_accounts add column if not exists installment_number integer default 1;
alter table public.scheduled_accounts add column if not exists series_id uuid;
alter table public.scheduled_accounts add column if not exists paid boolean not null default false;
alter table public.scheduled_accounts add column if not exists paid_at timestamptz;
